export type Role = 'mid' | 'jungle' | 'gold' | 'exp' | 'roam' | 'idk'

export type Player = {
  name: string
  role: Role
  roleLabel: string
  image: string
}

// Resolved hex/oklch values instead of CSS vars (CSS vars don't resolve in inline style strings)
export const roleColors: Record<Role, string> = {
  gold:   'oklch(0.8 0.16 75)',
  jungle: 'oklch(0.82 0.2 145)',
  roam:   'oklch(0.82 0.13 215)',
  mid:    'oklch(0.65 0.22 300)',
  exp:    'oklch(0.65 0.22 25)',
  idk:    'oklch(0.7 0.01 260)',
}

export const filters: { id: 'all' | Role; label: string }[] = [
  { id: 'all',    label: 'All' },
  { id: 'mid',    label: 'Mid' },
  { id: 'jungle', label: 'Jungle' },
  { id: 'gold',   label: 'Gold' },
  { id: 'exp',    label: 'EXP' },
  { id: 'roam',   label: 'Roam' },
  { id: 'idk',    label: 'IDK' },
]

export const players: Player[] = [
  { name: 'Yusuf',  role: 'gold',   roleLabel: 'Gold Laner',        image: '/team/yusuf.jpg' },
  { name: 'Haidar', role: 'jungle', roleLabel: 'Jungler',           image: '/team/haidar.jpg' },
  { name: 'Faris',  role: 'roam',   roleLabel: 'Roamer',            image: '/team/faris.jpg' },
  { name: 'Mikail', role: 'mid',    roleLabel: 'Mid Laner',         image: '/team/mikail.jpg' },
  { name: 'Ridwan', role: 'exp',    roleLabel: 'EXP Laner',         image: '/team/ridwan.jpg' },
  { name: 'Fairus', role: 'mid',    roleLabel: 'Mid Laner',         image: '/team/fairus.jpg' },
  { name: 'Affaw',  role: 'gold',   roleLabel: 'Gold Laner',        image: '/team/affaw.jpg' },
  { name: 'Alif',   role: 'jungle', roleLabel: 'Jungler (Poke)',    image: '/team/alif.jpg' },
  { name: 'Fatir',  role: 'idk',    roleLabel: 'IDK',               image: '/team/fatir.jpg' },
  { name: 'Robin',  role: 'idk',    roleLabel: 'IDK',               image: '/team/robin.jpg' },
]
