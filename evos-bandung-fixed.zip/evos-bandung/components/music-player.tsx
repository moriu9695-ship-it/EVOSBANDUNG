'use client'

import { Pause, Play, Volume2 } from 'lucide-react'
import { useEffect, useRef, useState } from 'react'

function format(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00'
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s < 10 ? '0' : ''}${s}`
}

export function MusicPlayer() {
  const audioRef = useRef<HTMLAudioElement>(null)
  const [playing, setPlaying] = useState(false)
  const [current, setCurrent] = useState(0)
  const [duration, setDuration] = useState(0)
  const [volume, setVolume] = useState(0.7)

  useEffect(() => {
    if (audioRef.current) audioRef.current.volume = volume
  }, [volume])

  const toggle = () => {
    const audio = audioRef.current
    if (!audio) return
    if (audio.paused) {
      void audio.play()
      setPlaying(true)
    } else {
      audio.pause()
      setPlaying(false)
    }
  }

  const seek = (e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current
    if (!audio || !duration) return
    const rect = e.currentTarget.getBoundingClientRect()
    const pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width))
    audio.currentTime = pct * duration
  }

  const handleEnded = () => {
    const audio = audioRef.current
    if (audio) audio.currentTime = 0
    setPlaying(false)
    setCurrent(0)
  }

  const progress = duration ? (current / duration) * 100 : 0

  return (
    <div className="flex flex-wrap items-center gap-4 border-y border-cyan/20 bg-[linear-gradient(90deg,oklch(0.16_0.04_330),oklch(0.14_0.03_320),oklch(0.16_0.04_330))] px-5 py-3 md:px-10">
      {/* Track info */}
      <div className="flex min-w-0 items-center gap-3 md:min-w-[260px]">
        <div
          className={`disc-spin flex size-11 shrink-0 items-center justify-center rounded-full bg-[conic-gradient(var(--cyan),oklch(0.3_0.1_255),var(--cyan))] ${
            playing ? 'playing' : ''
          }`}
        >
          <span className="size-3.5 rounded-full bg-background" />
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold tracking-wide text-foreground">
            Married With Children
          </p>
          <p className="truncate text-xs text-muted-foreground">Oasis</p>
        </div>
      </div>

      {/* Play button */}
      <button
        type="button"
        onClick={toggle}
        aria-label={playing ? 'Pause' : 'Play'}
        className="flex size-10 items-center justify-center rounded-full border border-cyan/30 bg-cyan/15 text-foreground transition-all hover:border-cyan hover:bg-cyan hover:text-primary-foreground hover:shadow-[0_0_20px_rgba(0,229,255,0.5)]"
      >
        {playing ? (
          <Pause className="size-4" fill="currentColor" />
        ) : (
          <Play className="size-4 translate-x-px" fill="currentColor" />
        )}
      </button>

      {/* Progress */}
      <div className="flex min-w-[180px] flex-1 items-center gap-3">
        <span className="w-9 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
          {format(current)}
        </span>
        <div
          onClick={seek}
          role="slider"
          aria-label="Seek"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={Math.round(progress)}
          tabIndex={0}
          onKeyDown={(e) => {
            const audio = audioRef.current
            if (!audio || !duration) return
            if (e.key === 'ArrowRight') audio.currentTime = Math.min(duration, audio.currentTime + 5)
            if (e.key === 'ArrowLeft')  audio.currentTime = Math.max(0, audio.currentTime - 5)
          }}
          className="relative h-1.5 flex-1 cursor-pointer rounded-full bg-foreground/10"
        >
          <div
            className="pointer-events-none h-full rounded-full bg-gradient-to-r from-cyan to-cyan/70 transition-[width] duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>
        <span className="w-9 shrink-0 text-xs tabular-nums text-muted-foreground">
          {format(duration)}
        </span>
      </div>

      {/* Volume */}
      <div className="flex items-center gap-2">
        <Volume2 className="size-4 text-muted-foreground" />
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={volume}
          onChange={(e) => setVolume(Number(e.target.value))}
          aria-label="Volume"
          className="h-1 w-20 cursor-pointer appearance-none rounded-full bg-foreground/15 accent-cyan"
        />
      </div>

      <audio
        ref={audioRef}
        src="/team/track.mp3"
        preload="metadata"
        onTimeUpdate={(e) => setCurrent(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => setDuration(e.currentTarget.duration)}
        onEnded={handleEnded}
      />
    </div>
  )
}
