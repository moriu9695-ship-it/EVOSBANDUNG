'use client'

import Image from 'next/image'
import { useState } from 'react'
import { filters, players, roleColors, type Role } from '@/lib/roster'

export function Roster() {
  const [active, setActive] = useState<'all' | Role>('all')

  const visible = players.filter((p) => active === 'all' || p.role === active)

  return (
    <section id="roster" className="px-5 pb-20 md:px-10">
      {/* Section header */}
      <div className="px-2 pb-3 pt-16 text-center">
        <span className="mb-3 inline-block text-xs font-semibold uppercase tracking-[0.3em] text-cyan">
          Meet The Team
        </span>
        <h2 className="font-heading text-3xl font-bold uppercase tracking-[0.12em] text-foreground md:text-4xl">
          Main Roster
        </h2>
        <div className="mx-auto mt-4 h-0.5 w-16 rounded-full bg-cyan" />
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center justify-center gap-2 py-8">
        {filters.map((f) => {
          const isActive = active === f.id
          return (
            <button
              key={f.id}
              type="button"
              onClick={() => setActive(f.id)}
              className={`rounded-full border px-5 py-2 text-sm font-semibold uppercase tracking-wider transition-all ${
                isActive
                  ? 'border-cyan bg-cyan text-primary-foreground shadow-[0_0_20px_rgba(0,229,255,0.45)]'
                  : 'border-border text-muted-foreground hover:border-cyan hover:text-foreground'
              }`}
            >
              {f.label}
            </button>
          )
        })}
      </div>

      {/* Player grid */}
      <div className="mx-auto grid max-w-6xl grid-cols-2 gap-4 sm:grid-cols-3 md:gap-5 lg:grid-cols-4">
        {visible.map((player) => {
          const color = roleColors[player.role]
          return (
            <article
              key={player.name}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card transition-all duration-300 hover:-translate-y-2"
              style={
                {
                  '--role': color,
                } as React.CSSProperties
              }
            >
              <div className="relative h-56 overflow-hidden md:h-72">
                {/* Role color bar */}
                <span
                  className="absolute inset-x-0 top-0 z-20 h-[3px]"
                  style={{ background: color }}
                />
                <Image
                  src={player.image || '/placeholder.svg'}
                  alt={`${player.name} — ${player.roleLabel}`}
                  fill
                  sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
                  className="object-cover brightness-75 saturate-[0.9] transition-all duration-500 group-hover:scale-105 group-hover:brightness-100 group-hover:saturate-100"
                />
                {/* Gradient overlay */}
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent" />
              </div>

              <div className="relative p-4">
                <h3 className="font-heading mb-2 text-sm font-bold uppercase tracking-wider text-foreground">
                  {player.name}
                </h3>
                <span
                  className="inline-block rounded border px-2.5 py-1 text-xs font-semibold uppercase tracking-wider"
                  style={{ color, borderColor: color }}
                >
                  {player.roleLabel}
                </span>
              </div>

              {/* Hover glow */}
              <div
                className="pointer-events-none absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                style={{ boxShadow: `0 20px 50px -10px ${color}` }}
              />
            </article>
          )
        })}
      </div>
    </section>
  )
}
