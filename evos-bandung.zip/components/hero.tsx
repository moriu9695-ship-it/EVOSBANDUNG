export function Hero() {
  return (
    <section
      id="home"
      className="relative flex h-[480px] flex-col items-center justify-center overflow-hidden text-center md:h-[520px]"
    >
      {/* Background layers */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center_top,oklch(0.2_0.06_330)_0%,var(--background)_70%)]" />
      <div className="hero-grid absolute inset-0" aria-hidden />
      <div
        className="hero-glow pointer-events-none absolute left-1/2 top-[32%] h-[300px] w-[600px] max-w-[90vw] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(ellipse,color-mix(in_oklab,var(--cyan)_28%,transparent)_0%,transparent_70%)] blur-2xl"
        aria-hidden
      />

      <div className="relative z-10 px-4">
        <span className="mb-5 inline-block rounded border border-cyan/40 bg-cyan/15 px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.25em] text-cyan">
          Mobile Legends Division
        </span>

        <h1 className="font-heading bg-gradient-to-br from-foreground via-foreground to-cyan bg-clip-text text-5xl font-black uppercase leading-none tracking-[0.06em] text-transparent drop-shadow-[0_0_30px_rgba(0,229,255,0.4)] md:text-7xl">
          EVOS Bandung
        </h1>

        <p className="mt-4 text-base uppercase tracking-[0.35em] text-muted-foreground md:text-lg">
          Est. 2024 &nbsp;•&nbsp; West Java
        </p>

        <div className="mx-auto mt-6 h-[3px] w-28 rounded-full bg-gradient-to-r from-transparent via-cyan to-transparent" />
      </div>
    </section>
  )
}
