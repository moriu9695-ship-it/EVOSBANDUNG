import Image from 'next/image'

const links = [
  { href: '#home', label: 'Home' },
  { href: '#roster', label: 'Roster' },
  { href: '#achievements', label: 'Achievements' },
]

export function Topbar() {
  return (
    <header className="sticky top-0 z-50 flex flex-col items-center gap-3 border-b border-border bg-background/85 px-6 py-3 backdrop-blur-xl">
      <a href="#home" className="flex items-center justify-center">
        <Image
          src="/team/logo.png"
          alt="EVOS Bandung logo"
          width={64}
          height={64}
          priority
          className="h-14 w-auto drop-shadow-[0_0_14px_rgba(0,229,255,0.55)]"
        />
      </a>
      <nav className="flex flex-wrap items-center justify-center gap-1.5">
        {links.map((link) => (
          <a
            key={link.label}
            href={link.href}
            className="rounded-md border border-transparent px-4 py-2 text-sm font-semibold uppercase tracking-widest text-muted-foreground transition-colors hover:border-cyan hover:bg-cyan/10 hover:text-foreground"
          >
            {link.label}
          </a>
        ))}
      </nav>
    </header>
  )
}
