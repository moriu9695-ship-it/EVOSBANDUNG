export function SiteFooter() {
  return (
    <footer
      id="achievements"
      className="border-t border-border bg-[oklch(0.1_0.015_275)] px-5 py-10 text-center text-sm uppercase tracking-[0.2em] text-muted-foreground"
    >
      &copy; 2024 <span className="text-cyan">EVOS Bandung</span> &nbsp;|&nbsp;
      Mobile Legends Division
    </footer>
  )
}
