import { Hero } from '@/components/hero'
import { MusicPlayer } from '@/components/music-player'
import { Roster } from '@/components/roster'
import { SiteFooter } from '@/components/site-footer'
import { Topbar } from '@/components/topbar'

export default function Page() {
  return (
    <main className="min-h-screen bg-background">
      <Topbar />
      <Hero />
      <MusicPlayer />
      <Roster />
      <SiteFooter />
    </main>
  )
}
